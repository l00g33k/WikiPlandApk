
if ($ctrl->{'os'} eq 'and') {
    $ctrl->{'droid'}->makeToast('l00_toast.pl');
}

1;
