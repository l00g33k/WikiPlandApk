vim l00://found.txt
