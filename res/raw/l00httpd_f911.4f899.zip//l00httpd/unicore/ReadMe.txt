2005 March 30

Welcome to the Unicode Character Database

This directory contains contributory data files
for the Unicode Character Database of the Unicode Standard. 

Copyright (c) 1991-2005 Unicode, Inc.
For terms of use, see http://www.unicode.org/terms_of_use.html

For an overview of how to access a specific version of 
the Unicode Character Database (UCD) and other information, see:

http://www.unicode.org/ucd/

If you accessed this file via the URL:

http://www.unicode.org/Public/UNIDATA/ReadMe.txt

then you are looking at the most current version of the UCD. 
Otherwise the version number of the UCD is part of the path name. 

The file UCD.html in this directory, as well as any file 
headers, where present, also identify the version of the UCD.
