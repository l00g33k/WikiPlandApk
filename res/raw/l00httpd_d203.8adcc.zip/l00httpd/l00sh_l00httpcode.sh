while [ 1 ]; do
busybox clear
echo shorthand: = is l00http_ , _ is l00_
echo al00Blowfish_PP.pm..2_ascii.pl..........3_chart.pl..........
echo b_crypt_ex_1.pl.....2_crypt_ex_2.pl.....3_do.pl.............
echo c_pwget.pl..........2_vil00httpd_.pl....3_wavgen.pl.........
echo dl00backup.pm.......2l00base64.pm.......3l00crypt.pm........
echo el00host_filetools.p2=adb.pl............3=blog.pl...........
echo f=cal.pl............2=clip.pl...........3=coorcalc.pl.......
echo g=crypt.pl..........2=dirnotes.pl.......3=do.pl.............
echo h=edit.pl...........2=eval.pl...........3=filecrypt.pl......
echo i=find.pl...........2=gps.pl............3=gpsmap.pl.........
echo j=hello.pl..........2=hexview.pl........3=jetlag.pl.........
echo k=kml.pl............2=launcher.pl.......3=ls.pl.............
echo l=myfriends.pl......2=notify.pl.........3=periocam.pl.......
echo xz exit
read sel
echo $sel

if [ $sel = "a" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00Blowfish_PP.pm; fi
if [ $sel = "aa" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00_ascii.pl; fi
if [ $sel = "aaa" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00_chart.pl; fi
if [ $sel = "b" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00_crypt_ex_1.pl; fi
if [ $sel = "bb" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00_crypt_ex_2.pl; fi
if [ $sel = "bbb" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00_do.pl; fi
if [ $sel = "c" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00_pwget.pl; fi
if [ $sel = "cc" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00_vil00httpd_.pl; fi
if [ $sel = "ccc" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00_wavgen.pl; fi
if [ $sel = "d" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00backup.pm; fi
if [ $sel = "dd" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00base64.pm; fi
if [ $sel = "ddd" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00crypt.pm; fi
if [ $sel = "e" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00host_filetools.pl; fi
if [ $sel = "ee" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_adb.pl; fi
if [ $sel = "eee" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_blog.pl; fi
if [ $sel = "f" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_cal.pl; fi
if [ $sel = "ff" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_clip.pl; fi
if [ $sel = "fff" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_coorcalc.pl; fi
if [ $sel = "g" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_crypt.pl; fi
if [ $sel = "gg" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_dirnotes.pl; fi
if [ $sel = "ggg" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_do.pl; fi
if [ $sel = "h" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_edit.pl; fi
if [ $sel = "hh" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_eval.pl; fi
if [ $sel = "hhh" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_filecrypt.pl; fi
if [ $sel = "i" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_find.pl; fi
if [ $sel = "ii" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_gps.pl; fi
if [ $sel = "iii" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_gpsmap.pl; fi
if [ $sel = "j" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_hello.pl; fi
if [ $sel = "jj" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_hexview.pl; fi
if [ $sel = "jjj" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_jetlag.pl; fi
if [ $sel = "k" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_kml.pl; fi
if [ $sel = "kk" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_launcher.pl; fi
if [ $sel = "kkk" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_ls.pl; fi
if [ $sel = "l" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_myfriends.pl; fi
if [ $sel = "ll" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_notify.pl; fi
if [ $sel = "lll" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_periocam.pl; fi
if [ $sel = "m" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_periodic.pl; fi
if [ $sel = "mm" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_perioifconfig.pl; fi
if [ $sel = "mmm" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_periolog.pl; fi
if [ $sel = "n" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_perionetstat.pl; fi
if [ $sel = "nn" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_play.pl; fi
if [ $sel = "nnn" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_playcopy.pl; fi
if [ $sel = "o" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_readme.pl; fi
if [ $sel = "oo" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_recedit.pl; fi
if [ $sel = "ooo" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_reminder.pl; fi
if [ $sel = "p" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_scratch.pl; fi
if [ $sel = "pp" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_screen.pl; fi
if [ $sel = "ppp" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_search.pl; fi
if [ $sel = "q" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_shell.pl; fi
if [ $sel = "qq" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_sleep.pl; fi
if [ $sel = "qqq" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_solver.pl; fi
if [ $sel = "r" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_speech.pl; fi
if [ $sel = "rr" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_table.pl; fi
if [ $sel = "rrr" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_tableedit.pl; fi
if [ $sel = "s" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_timelog.pl; fi
if [ $sel = "ss" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_timestamp.pl; fi
if [ $sel = "sss" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_toast.pl; fi
if [ $sel = "t" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_tr.pl; fi
if [ $sel = "tt" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_twitter.pl; fi
if [ $sel = "ttt" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_txtdopl.pl; fi
if [ $sel = "u" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_view.pl; fi
if [ $sel = "uu" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00http_wget.pl; fi
if [ $sel = "uuu" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00httpd.pl; fi
if [ $sel = "v" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00httpd.pm; fi
if [ $sel = "vv" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00mktime.pm; fi
if [ $sel = "vvv" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00wget.pm; fi
if [ $sel = "w" ]; then
busybox vi /sdcard/sl4a/scripts/l00httpd/l00wikihtml.pm; fi

if [ $sel = "xz" ]; then
break; fi

done
