# Release under GPLv2 or later version by l00g33k@gmail.com, 2010/02/14
use warnings;
use strict;

package l00httpd;

#use l00httpd;      # used for findInBuf


#$buf = &l00httpd::dumphashbuf ("gps", $buf);
sub dumphashbuf {
    my ($name, $hash) = @_;
    my ($tmp, $key, $buf);
    $buf = '';
    for $key (keys %$hash) {
        $tmp = $hash->{$key};
        if (defined ($tmp)) {
            $buf .= "$name->$key => $tmp\n";
            if (ref $tmp eq 'HASH') {
                $buf .= &dumphashbuf ("$name->$key", $tmp);
            } elsif ($key eq 'result') {
#               $buf .= &dumphashbuf ("$name->$key", $tmp);
            }
        } else {
            $buf .= "$name->$key => (undef)\n";
        }
    }
    $buf;
}

#$buf = $ctrl->{'droid'}->readLocation();
#&l00httpd::dumphash ("gps", $buf);
sub dumphash {
    my ($name, $hash) = @_;
    my ($tmp, $key);
    #print "$name is $hash\n";
    for $key (keys %$hash) {
        $tmp = $hash->{$key};
        if (defined ($tmp)) {
            print "$name->$key => $tmp\n";
            if (ref $tmp eq 'HASH') {
                &dumphash ("$name->$key", $tmp);
            } elsif ($key eq 'result') {
#               &dumphash ("$name->$key", $tmp);
            }
        } else {
            print "$name->$key => (undef)\n";
        }
    }
}

#$found .= &l00httpd::findInBuf ($findtext, $block, $buf);
sub findInBuf  {
    # $findtext : string to find
    # $block    : text block marker
    # $buf      : find string in $buf
    my ($findtext, $block, $buf) = @_;
    my ($hit, $found, $blocktext, $line);
 
    # find them
    $hit = 0;
    $found = "";
    $blocktext = "";
    foreach $line (split ("\n", $buf)) {
        if ($line =~ /$block/i) {
            # found new block
            if ($hit) {
                # report if found
                $found .= "$blocktext";
            }
            $hit = 0;
            $blocktext = "";
        }
        if ($line =~ /$findtext/i) {
            $hit = 1;
        }
        $blocktext .= "$line\n";
    }
    if ($hit) {
        $found .= "$blocktext";
    }
    $found;
}


1;

