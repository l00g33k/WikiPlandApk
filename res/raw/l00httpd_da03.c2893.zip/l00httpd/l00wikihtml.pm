package l00wikihtml;

use l00httpd;
my (@toclist, $java);


# collapsible Javascript tree: http://webpageworkshop.co.uk/main/article11

$java = "\n".
"<script type=\"text/javascript\">\n".
"var dge=document.getElementById;\n".
"function cl_expcol(a){\n".
"    if(!dge)return;\n".
"    document.getElementById(a).style.display = \n".
"        (document.getElementById(a).style.display=='none') ? 'block':'none';\n".
"}\n".
"</script>\n\n";

my (%colorlu);
$colorlu{'r'} = 'red';
$colorlu{'y'} = 'yellow';
$colorlu{'l'} = 'lime';
$colorlu{'s'} = 'silver';
$colorlu{'a'} = 'aqua';
$colorlu{'f'} = 'fuchsia';
$colorlu{'g'} = 'gray';
$colorlu{'o'} = 'olive';


sub makejavatoc {
    my ($lvl,$ttl, $lvltop, $order, %treetop, $thislvl, $needclose);
    my ($ulid, $output);
    my ($jump, $url, $anchor, $tag);

    $lvltop = 5;
    $order = 0;
    $thislvl = 0;
    $needclose = 0;
    $ulid = 1;

    $output = $java;

    $output .= "<ul>\n";
    foreach $_ (@toclist) {
        ($lvl,$ttl) = split ('\.\.');
        $lvl--;
        if ($lvl < $lvltop) {
            $lvltop = $lvl;
        }
        for ($thislvl; $thislvl > $lvl; $thislvl--) {
            $output .= '  ' x $thislvl . "</li>\n";
            $output .= '  ' x $thislvl . "</ul>\n";
        }
        for ($thislvl; $thislvl < $lvl; $thislvl++) {
            $output .= '  ' x ($thislvl + 1) . "<a href=\"javascript:cl_expcol('ulid$ulid');\">--</a>\n";
            $output .= '  ' x ($thislvl + 1) . "<ul id=\"ulid$ulid\">\n";
            $ulid++;
            $needclose = 0;
        }
        if ($needclose) {
            $needclose = 0;
            $output .= '  ' x $thislvl . "</li>\n";
        }
        ($jump, $anchor, $tag) = &makeanchor ($thislvl, $ttl);
        $jump =~ s/&nbsp;//g;
        $jump =~ s/<br>//g;
        $jump =~ s/\n//g;
        $output .= '  ' x $thislvl . "<li>$jump\n";
        $needclose = 1;
        $order++;
    }
    for ($thislvl; $thislvl >= 0; $thislvl--) {
        $output .= '  ' x $thislvl . "</li>\n";
        $output .= '  ' x $thislvl . "</ul>\n";
    }
#    $output .= "</li>\n";
#    $output .= "</ul>\n";

    $output;
}


sub makeanchor {
    my ($lvl, $ttl) = @_;
    my ($jump, $url, $anchor, $tag);

    $tag = $ttl;
    $tag =~ s/[^0-9A-Za-z]/_/g;

    if ($lvl > 0) {
        $jump = "&nbsp;&nbsp;" x ($lvl - 1);
    } else {
        $jump = '';
    }
    $url = "<a href=\"#$tag\">$ttl</a>";
    $jump .= "$url<br>\n";
    $anchor = "<a name=\"$tag\"></a>";

    ($jump, $anchor, $tag);
}

sub wikihtml {
    # flags: 1='bookmark' is on
    #        2=prefix chapter number
    #        4=bare, no header/footer
    # $ctrl: system variables
    # $pname: current path for relateive wikiword links
    my ($ctrl, $pname, $inbuf, $flags) = @_;
    my ($oubuf, $bulvl, $tx, $lvn, $desc, $http, $toc, $toccol);
    my ($intbl, @cols, $ii, $lv, $el, $url, @el, @els);
    my ($jump, $anchor, $last, $tmp, $color, $tag, $bareclip);
    my ($desc, $url, $bullet, $bkmking, $clip, $bookmarkkeyfound);
    my ($lnno, $flaged, $postsit, @chlvls, $thischlvl, $lastchlvl);

    undef @chlvls;
    undef $lastchlvl;

    $bookmarkkeyfound = 0;
    if (($flags & 1) == 0) {
        # not specified for BOOKMARK
        # search %BOOKMARK% in first 4000 lines
        $tmp = 0;
        foreach $_  (split ("\n", $inbuf)) {
            if (/^%BOOKMARK%/) {
                $bookmarkkeyfound = 1;
                last;
            }
            if ($tmp++ > 4000) {
                last;
            }
        }
    }
    if ((($flags & 1) == 1) || ($bookmarkkeyfound != 0)) {
        # flags: 1='bookmark' is on or contains '%BOOKMARK%' at the beginning 
        $oubuf = $inbuf;
        $inbuf = '';
        $bullet = 0;
        $bkmking = 0;
        foreach $_  (split ("\n", $oubuf)) {
            s/\r//g;
            s/\n//g;
            if (/^=/) {
                # headings
                $inbuf .= "$_\n";
            } elsif (/^%BOOKMARK%/) {
                # restart bookmarking
                $bkmking = 1;
            } elsif (/^%END%/) {
                # ends bookmarking
                $bkmking = 0;
            } elsif ($bkmking == 0) {
                # not bookmarking
                $inbuf .= "$_\n";
            } elsif (/^\*/) {
                # bullets, no linefeed
                $inbuf .= "$_ ";
                $bullet = 1;
            } elsif (($desc, $clip) = /^ *(.*) *\|\|(.+)$/) {
                # clip
                $desc =~ s/ +$//g;
                $bareclip = 0;
                if ($desc eq '') {
		            $desc = $clip;
                    $bareclip = 1;
		        }
                #http://127.0.0.1:20337/clip.pl?update=Copy+to+clipboard&clip=Asd+ddf
                $clip =~ s/ /+/g;
                #http://127.0.0.1:20337/clip.pl?update=Copy+to+clipboard&clip=
                #%3A%2F
                $clip =~ s/:/%3A/g;
                $clip =~ s/&/%26/g;
                $clip =~ s/=/%3D/g;
                $clip =~ s/"/%22/g;
                $clip =~ s/\//%2F/g;
                $clip =~ s/\|/%7C/g;
                $url = "/clip.pl/clip.htm?update=Copy+to+clipboard&clip=$clip";
                $url = "[[$url|$desc]]";
                if ($bareclip) {
                    #$url = "&lt;$url&gt;";
		        }
                if ($last =~ /^\*/) {
                    $inbuf .= "$url";
                } else {
                    $inbuf .= " - $url";
                }
            } elsif (($url) = /^\?\| *(.+)$/) {
                $desc = $url;
                # bookmarks
                $desc =~ s/ +$//g;
                if ($last =~ /^\*/) {
                    $inbuf .= "[[$url|$desc]]";
                } else {
                    $inbuf .= " - [[$url|$desc]]";
                }
            } elsif (($desc, $url) = /^(.+) *\| *(.+)$/) {
                # bookmarks
                $desc =~ s/ +$//g;
                if ($last =~ /^\*/) {
                    $inbuf .= "[[$url|$desc]]";
                } else {
                    $inbuf .= " - [[$url|$desc]]";
                }
            } elsif (/^ *$/) {
                # newline
                $inbuf .= "\n";
                $bullet = 0;
            } else {
                if ($bullet) {
                    if ($last =~ /^\*/) {
                        $inbuf .= "$_";
                    } else {
                        $inbuf .= " - $_";
                    }
                } else {
                    $inbuf .= "$_\n";
                }
            }
            $last = $_;
        }
    }
    #print "\n::inbuf::\n$inbuf\n";

    # Start generating HTML output in $oubuf
    $oubuf = "<a name=\"___top___\"></a>";
    $bulvl = 0;
    $toc = '';
    $toccol = '';
    
    $intbl = 0;
    $ispre = 0;
    undef @toclist;
    $lnno = 0;
    $flaged = '';
    $postsit = '';
    foreach $_  (split ("\n", $inbuf)) {
        s/\r//g;
        $lnno++;

        # %DATETIME% expansion
        if (/%DATETIME%/) {
                # date/time substitution
                $tmp = $ctrl->{'now_string'};
                $tmp =~ s/ /T/;
                s/%DATETIME%/$tmp/g;
                $inbuf .= "$_\n";
        }

        # Twiki compatibility
        ## convert '   * '
        if (($lv,$tx) = /^( +)\* (.*)$/) {
            $lv = length ($lv);
            if (($lv % 3) == 0) {
                $lv /= 3;
                $_ = '*' x $lv . " $tx";
            }
        }
        ## convert ---+++
        if (($lv,$tx) = /^---(\++) (.*)$/) {
            $lv = length ($lv);
            $_ = '=' x $lv . "$tx" . '=' x $lv;
        }
        ## convert [[][]] to [[|]]
        s/\[\[(.*?)\]\[(.*?)\]\]/[[$1|$2]]/g;
        # end Twiki compatibility

        # processing each line
        s/\[\[toc\]\]/%TOC%/;   # converts wikispaces' [toc] to %TOC%

        # --- for <hr>
        if (/^---+ *$/) {
            $oubuf .=  "<hr>\n";
            next;
        }

        # lines ending in ??? gets a colored Highlight link before TOC
        # aka post it note
        # ???, ???r, ???y, ???l, ???s
        if (/^(.*)\?\?\?([rylsafg]*)$/) {
            $tmp = $1;
            if ($2 eq 'r')      { $color = 'red';
            } elsif ($2 eq 'y') { $color = 'yellow';
            } elsif ($2 eq 'l') { $color = 'lime';
            } elsif ($2 eq 's') { $color = 'silver';
            } elsif ($2 eq 'a') { $color = 'aqua';
            } elsif ($2 eq 'f') { $color = 'fuchsia';
            } elsif ($2 eq 'g') { $color = 'gray';
            } else              { $color = 'olive';
            }
            
            # drops *
            $tmp =~ s/^\*+ +//;
            # drops ==
            $tmp =~ s/^=+//;
            $tmp =~ s/=+$//;

            # make a sortable TOC entry
            $tmp = "<!-- $tmp --><font style=\"color:black;background-color:$color\"><a href=\"#lnno$lnno\">$tmp</a></font><br>\n";
            $postsit .= $tmp;
            $oubuf .=  "<a name=\"lnno$lnno\">";
            # remove !!!
            s/\?\?\?[rylsafg]*$//;
            if (/^=.+=$/) {
                # '=' interferes with heading shorthand, global replace ____EqSg____ = later
                s/^(=+)([^=]+)(=+)$/$1<font style____EqSg____"color:black;background-color:$color">$2<\/font>$3/g;
            } else {
                $_ = "<font style=\"color:black;background-color:$color\">$_</font>";
            }
            $_ .= " <a href=\"#___top___\">top</a>" .
                  " <a href=\"#__toc__\">toc</a>";
        }

        # lines ending in !!! gets a Highlight link before TOC
        if (/^(.*)!!!$/) {
            $tmp = $1;
            # drops *
            $tmp =~ s/^\*+ +//;
            # drops ==
            $tmp =~ s/^=+//;
            $tmp =~ s/=+$//;
            $flaged .= "<a href=\"#lnno$lnno\">$tmp</a><br>\n";
            $oubuf .=  "<a name=\"lnno$lnno\">";
            # remove !!!
            s/!!!$//;
        }

        # process headings
        if (@el = /^(=+)([^=]+?)(=+)(.*)$/) {
            if ($el[0] eq $el[2]) {
                $el[1] =~ s/____EqSg____/=/g;
                # left === must match right ===
                # headings must start from column 0
                if ($bulvl > 0) {
                    # generate closing bullets
                    for (; $bulvl > 0; $bulvl--) {
                        $oubuf .=  "</ul>";
                    }
                    $oubuf .= "\n";
                }
                if ($flags & 2) {
                    $thischlvl = length($el[0]);
                    if (defined ($lastchlvl)) {
                        # increment current chapter level
                        if ($lastchlvl == $thischlvl) {
                            # increment current level
                            if (!defined ($chlvls[$thischlvl])) {
                                # 1 if non existent
                                $chlvls[$thischlvl] = 1;
                            } else {
                                # else increment
                                $chlvls[$thischlvl]++;
                            }
                            # create if non existence
                            for ($ii = 1; $ii < $thischlvl; $ii++) {
                                if (!defined ($chlvls[$ii])) {
                                    # 1 if non existent
                                    $chlvls[$ii] = 1;
                                }
                            }
                        } elsif ($lastchlvl > $thischlvl) {
                            # increment higher level
                            $chlvls[$thischlvl]++;
                        } else { # ($lastchlvl < $thischlvl)
                            # increment lower level
                            for ($ii = $lastchlvl + 1; $ii <= $thischlvl; $ii++) {
                                $chlvls[$ii] = 1;
                            }
                        }
                    } else {
                        # this is the first time ever.  Everything starts at 1.1.
                        for ($ii = 1; $ii <= $thischlvl; $ii++) {
                            $chlvls[$ii] = 1;
                        }
                    }
                    $tmp = '';
                    for ($ii = 1; $ii <= $thischlvl; $ii++) {
                        $tmp .= "$chlvls[$ii].";
                    }
                    $lastchlvl = $thischlvl;
                    # no line number in chapter title # $el[1] = "$tmp $el[1] ($lnno)";
                    $el[1] = "$tmp $el[1]";
                }
                # make anchor
                ($jump, $anchor, $tag) = &makeanchor (length($el[0]), $el[1]);
                push (@toclist, length($el[0])."..$el[1]");

                $toc .= $jump;
                $_ = $el[1];
                # wikiword links
#d612                s|([ ])([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1<a href=\"/ls.pl?path=$pname$2.txt\">$2</a>|g;
                s|([ ])([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1<a href=\"/ls.pl/$2.htm?path=$pname$2.txt\">$2</a>|g;
                # special case when wiki word is the first word without leading space
#d612                s|^([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|<a href=\"/ls.pl?path=$pname$1.txt\">$1</a>|;
                s|^([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|<a href=\"/ls.pl/$1.htm?path=$pname$1.txt\">$1</a>|;
                # !not wiki
                s|!([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1|g;
                if ($flags & 4) {
                    # 'bare'
                    $_ = $anchor .
                         sprintf("<h%d>",length($el[0])) .
                         $_ .
                         sprintf("</h%d>",length($el[2])) .
                         $el[3];
                } else {
                    # normal
                    $_ = $anchor .
                         sprintf("<h%d>",length($el[0])) .
                         $_ .
                         " <a href=\"#$tag\">here</a>".
                         " <a href=\"#___top___\">top</a>" .
                         " <a href=\"#__toc__\">toc</a>" .
                         sprintf("</h%d>",length($el[2])) .
                         $el[3];
                }
                $oubuf .= "$_\n";
                next;
            }
        }
        # '=' interferes with heading shorthand, global replace ____EqSg____ = later
        s/____EqSg____/=/g;

        # %::INDEX::% processing
        if (/^::.+::$/ &&       # starts and ends with ::
            !/:::/) {           # no :::
            $oubuf .= "<a name=\"$_\"></a>\n";
            $toccol .= "<a href=\"#$_\">$_</a><br>\n";
        }

        # make http links
        s/\n//g;
        s/\r//g;
        # Makes http links a [[wikilink]]
        # For http(s) not preceeded by [|" becomes whatever [[http...]]
        s|([^\[\|"])(https*://[^ ]+)|$1\[\[$2\]\]|g;
        # make it work on column 0 too
#c518        s|^(https*://[^ ]+)|\[\[$1\]\]|;
        s|^(https*://[^ ]+)| \[\[$1\]\]|;
        # process multiple [[ ]] on the line
        @els = split (']]', $_);
        $_ = '';
        foreach $el (@els) {
            if (($tx,$url) = $el =~ /^(.+)\[\[(.+)$/) {
                # now have a line ending in only one pair of [[wikilink]]
                # i.e. $tx[[$url]]
#               ($tx,$url) = split ("]]", $el);

                if (($url =~ /^#/) && !($url =~ /\|/)) {
                    # local anchor
                    ($http) = ($url =~ /^#([^|]+)$/);
                    # i.e. $tx[[#$url]]
                    $_ .= $tx . "<a name=\"$http\">";
                } elsif ((($http, $desc) = ($url =~ /^#([^|]+)\|(.*)$/))) {
                    # i.e. $tx[[$url|desc]]
                    # link to local anchor
                    $_ .= $tx . "<a href=\"\#$http\">$desc</a>";
                } else {
                    if (!(($http, $desc) = ($url =~ /^([^|]+)\|(.*)$/))) {
                        # URL of form [[wikilink]] and not [[http|name]]
                        # description is the URL
                        $http = $url;
                        $desc = $url;
                    }
                    if ($http =~ m|^/|) {
                        # relative URL, use as is
                        # Palm TX wants to see ending in .htm
                        #$http .= '&tx=a.htm';
                        # add /abc.pl/abc.htm
                        $http =~ s|^/(\w+)\.pl|/$1.pl/$1.htm|;
                    } elsif (!($http =~ m|https*://|)) {
                        # make wikilink into l00httpd/ls.pl link
                        $tmp = $http;
                        if ($tmp =~ /^([^&#]+)/) {
                            # '#' to drop anchor
                            $tmp = $1;
                        }
#d612                        $http = "/ls.pl/$tmp?path=".$pname.$http;
                        $http = "/ls.pl/$tmp.htm?path=".$pname.$http;
                    }
                    $_ .= $tx . "<a href=\"$http\">$desc</a>";
                }
            } else {
                # just a bare line without [[wikilink]]
                $_ .= $el;
            }
        }


        # table
        if (/^\|\|/) {
            if ($intbl != 1) {
                $intbl = 1;
                if ($bulvl > 0) {
                    # generate closing bullets
                    for (; $bulvl > 0; $bulvl--) {
                        $oubuf .= "</ul>";
                    }
                    $oubuf .= "\n";
                }
                $oubuf .= "    <table border=\"1\" cellpadding=\"1\" cellspacing=\"1\">\n";
            }
            $oubuf .= "<tr>\n";
            # Perl/SL4A doesn't handle split ("\|\|", $_);????
            s/\|\|/``/g;
            @cols = split ("``", $_);
            for ($ii = 1; $ii <= $#cols; $ii++) {
                if ($cols[$ii] =~ /^ *$/) {
                    $oubuf .= "<td>&nbsp;</td>\n";
                } else {
                    $oubuf .= "<td>$cols[$ii]</td>\n";
                }
            }
            $oubuf .= "</tr>\n";
            # skip bullet processing
            next;
        } else {
            if ($intbl == 1) {
                $intbl = 0;
                $oubuf .= "</table>\n";
            }
        }

        # find <hr> and clear bullet level
        #if (/<hr>/) {
        #    if ($bulvl > 0) {
        #        # generate closing bullets
        #        for (; $bulvl > 0; $bulvl--) {
        #            $oubuf .=  "</ul>";
        #        }
        #        $oubuf .= "\n";
        #    }
        #}


        # process font styles
        # **bold**    <strong>bold</strong>
        s/ \*\*([^ *][^*]+[^ *])\*\*$/ <strong> $1 <\/strong> /;# at EOL
        s/^\*\*([^ *][^*]+[^ *])\*\* / <strong> $1 <\/strong> /;# at EOL
        s/^\*\*([^ *][^*]+[^ *])\*\*$/ <strong> $1 <\/strong> /;# at EOL
        while (s/ \*\*([^ *][^*]+[^ *])\*\* / <strong> $1 <\/strong> /) {
        }
        # *l*color bold**
        s/ \*([rylsafgo])\*(.+?)\*[rylsafgo]\*$/ <strong><font style="color:black;background-color:$colorlu{$1}">$2<\/font><\/strong> /;# at EOL
        s/^\*([rylsafgo])\*(.+?)\*[rylsafgo]\* / <strong><font style="color:black;background-color:$colorlu{$1}">$2<\/font><\/strong> /;# at EOL
        s/^\*([rylsafgo])\*(.+?)\*[rylsafgo]\*$/ <strong><font style="color:black;background-color:$colorlu{$1}">$2<\/font><\/strong> /;# at EOL
        while (s/ \*([rylsafgo])\*(.+?)\*[rylsafgo]\* / <strong><font style="color:black;background-color:$colorlu{$1}">$2<\/font><\/strong> /) {
        }
        # //italics// <em>italics</em>
        s/ \/\/([^ \/][^\/]+[^ \/])\/\/$/ <em> $1 <\/em> /;    # at EOL
        s/^\/\/([^ \/][^\/]+[^ \/])\/\/ / <em> $1 <\/em> /;    # at EOL
        s/^\/\/([^ \/][^\/]+[^ \/])\/\/$/ <em> $1 <\/em> /;    # at EOL
        while (s/ \/\/([^ \/][^\/]+[^ \/])\/\/ / <em> $1 <\/em> /) {
        }
        # __underline__   <u>underline</u>
        s/ __([^ _][^_]+[^ _])__$/ <u> $1 <\/u> /;           # at EOL
        s/^__([^ _][^_]+[^ _])__ / <u> $1 <\/u> /;           # at EOL
        s/^__([^ _][^_]+[^ _])__$/ <u> $1 <\/u> /;           # at EOL
        while (s/ __([^ _][^_]+[^ _])__ / <u> $1 <\/u> /) {
        }
        # {{monospace}}   <tt>monospace</tt>
        s/ \{\{([^ \}][^\}]+[^ \}])\}\}$/ <tt> $1 <\/tt> /;   # at EOL
        s/^\{\{([^ \}][^\}]+[^ \}])\}\} / <tt> $1 <\/tt> /;   # at EOL
        s/^\{\{([^ \}][^\}]+[^ \}])\}\}$/ <tt> $1 <\/tt> /;   # at EOL
        while (s/ \{\{([^ \}][^\}]+[^ \}])\}\} / <tt> $1 <\/tt> /) {
        }

        if (($lv,$tx) = /^(\*+) (.*)$/) {
            # process bullets
            $lvn = length ($lv);
            if ($lvn > $bulvl) {
                for (; $bulvl < $lvn; $bulvl++) {
                    $oubuf .=  "<ul>";
                }
            } elsif ($lvn < $bulvl) {
                for (; $bulvl > $lvn; $bulvl--) {
                    $oubuf .=  "</ul>";
                }
            }
            # wikiword links
            # Palm TX wants to see ending in .htm
            # old: ([A-Z]+[a-z]+[A-Z]+[^ ]*)
            # new: ([A-Z]+[a-z]+[A-Z]+[^ !@#$%^&*()+[\]{}]*\\|'";:/?,.<>])
            # new: ([A-Z]+[a-z]+[A-Z]+[^ !@#$%\^&*()+[\]{}]*\\|'";:/?,.<>])
            # new: ([A-Z]+[a-z]+[A-Z]+[^ !\@#\$%\^&*()+[\]{}*\\|'";:/?,.<>])
            # new: ([A-Z]+[a-z]+[A-Z]+[^ !\@#\$%\^&*()+\[\]{}*\\\|'";:/?,.<>])
            # new: ([A-Z]+[a-z]+[A-Z]+[^ \@#\$%\^&*()+\[\]{}*\\\|'";:/?,.<>])
            # new: ([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)
            #$tx =~ s|([ ])([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1<a href=\"/ls.pl?path=$pname$2.txt&tx=$2.htm\">$2</a>|g;
#d612            $tx =~ s|([ ])([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1<a href=\"/ls.pl?path=$pname$2.txt\">$2</a>|g;
            $tx =~ s|([ ])([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1<a href=\"/ls.pl/$2.htm?path=$pname$2.txt\">$2</a>|g;
            # special case when wiki word is the first word without leading space
            #$tx =~ s|^([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|<a href=\"/ls.pl?path=$pname$1.txt&tx=$1.htm\">$1</a>|;
#d612            $tx =~ s|^([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|<a href=\"/ls.pl?path=$pname$1.txt\">$1</a>|;
            $tx =~ s|^([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|<a href=\"/ls.pl/$1.htm?path=$pname$1.txt\">$1</a>|;
            # !not wiki
            $tx =~ s|!([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1|g;
            # rebase: fix wiki base directory when the l00httpd direct has been changed, like viewing on PC
            # in l00httpd.cfg
            #rebasefr^path=/sdcard/
            #rebaseto^path=c:/info/
            if (defined ($ctrl->{'rebasefr'}) &&
                defined ($ctrl->{'rebaseto'})) {
                $tx =~ s/$ctrl->{'rebasefr'}/$ctrl->{'rebaseto'}/g;
            }
            
            $oubuf .=  "<li>$tx</li>\n";
        } else {
            # any non bullet resets bullet level
            if ($bulvl > 0) {
                # generate closing bullets
                for (; $bulvl > 0; $bulvl--) {
                    $oubuf .=  "</ul>";
                }
                #$oubuf .= "\n";
            }
            # wikiword links
            # Palm TX wants to see ending in .htm
            #s|([ ])([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1<a href=\"/ls.pl?path=$pname$2.txt&tx=$2.htm\">$2</a>|g;
#d612            s|([ ])([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1<a href=\"/ls.pl?path=$pname$2.txt\">$2</a>|g;
            s|([ ])([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1<a href=\"/ls.pl/$2.htm?path=$pname$2.txt\">$2</a>|g;
            # special case when wiki word is the first word without leading space
            #s|^([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|<a href=\"/ls.pl?path=$pname$1.txt&tx=$1.htm\">$1</a>|;
#d612            s|^([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|<a href=\"/ls.pl?path=$pname$1.txt\">$1</a>|;
            s|^([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|<a href=\"/ls.pl/$1.htm?path=$pname$1.txt\">$1</a>|;
            # !not wiki
            s|!([A-Z]+[a-z]+[A-Z]+[0-9a-zA-Z_\-]*)|$1|g;
            if (/<pre>/) {
                $ispre = 1;
            }
            if (defined ($ctrl->{'rebasefr'}) &&
                defined ($ctrl->{'rebaseto'})) {
                s/$ctrl->{'rebasefr'}/$ctrl->{'rebaseto'}/g;
            }

            if ($ispre) {
                $oubuf .=  "$_\n";
            } else {
                $oubuf .=  "$_<br>\n";
            }
            if (/<\/pre>/) {
                $ispre = 0;
            }
        }



    }
    if ($bulvl > 0) {
        # generate closing bullets
        for (; $bulvl > 0; $bulvl--) {
            $oubuf .=  "</ul>";
        }
        $oubuf .= "\n";
    }
    if ($intbl == 1) {
        # generate closing table
        $oubuf .= "</table>\n";
    }

    # The next statement overwrites the old style TOC with 
    # collapsible Java TOC.  Uncomment to restore old style TOC
    $toc = &makejavatoc ();
#print $toc;
    if ($flaged ne '') {
        $flaged = "<b><i>BOOKMARKS:</i></b><br>$flaged<hr>\n";
    }
    if ($postsit ne '') {
        $postsit = join ("\n", sort (split ("\n", $postsit)));
        $postsit = "<b><i>POSTS-IT NOTE:</i></b><br>$postsit<hr>\n";
    }
    $toc = "<a name=\"__toc__\"></a>$postsit$flaged$toc<a name=\"__tocend__\"></a>";

    $toc =~ s/<br>$//;

    # Replace special %TOC% tag with the created $toc
    # There are 4 cases:
    #  at the beginning
    #  after \r
    #  after \n
    #  after any HTML tag '>'

    if ($toccol ne '') {
        $toc = "<a href=\"#::INDEX::\">jump to ::INDEX::</a><br>" . $toc;
    }

    $oubuf =~ s/hr>%TOC% *<br>/hr>$toc<hr>/g;
    $oubuf =~ s/br>%TOC% *<br>/br><hr>$toc<hr>/g;
    $oubuf =~ s/\/ul>%TOC% *<br>/\/ul><hr>$toc<hr>/g;
    $oubuf =~ s/\/a>%TOC% *<br>/\/a><hr>$toc<hr>/g;
    $oubuf =~ s/\r%TOC% *<br>/\r<hr>$toc<hr>/g;
    $oubuf =~ s/\n%TOC% *<br>/\n<hr>$toc<hr>/g;

    $oubuf =~ s/hr>%TOC%/hr>$toc<hr>/g;
    $oubuf =~ s/br>%TOC%/br><hr>$toc<hr>/g;
    $oubuf =~ s/\/ul>%TOC%/\/ul><hr>$toc<hr>/g;
    $oubuf =~ s/\/a>%TOC%/\/a><hr>$toc<hr>/g;
    $oubuf =~ s/\r%TOC%/\r<hr>$toc<hr>/g;
    $oubuf =~ s/\n%TOC%/\n<hr>$toc<hr>/g;

    if (($flags & 4) == 0) {
        # not 'bare'
        $oubuf .= " <a href=\"#___top___\">top</a>";
        $oubuf .= " <a href=\"#__toc__\">toc</a>";
    }

    if ($toccol ne '') {
        $toccol = join ("\n", sort (split ("\n", $toccol)));
        $toccol = "<a name=\"::INDEX::\"></a>" . $toccol;
#        $oubuf = "<a href=\"#::INDEX::\">jump to ::INDEX::</a><br>" . $oubuf;
        $tmp = '';
        foreach $_  (split ("\n", $oubuf)) {
            s/^%::INDEX::%/<hr>$toccol<hr>/;
            if ($tmp eq '') {
                $tmp = "$_";
            } else {
                $tmp .= "\n$_";
            }
        }
        $oubuf = $tmp;
    }

    # \n messes with lineno line count; take out
    #$oubuf =~ s/<a href/\n<a href/g;

# is this superceded by path=./ substitution in ls.pl?
# expand href="... path=./ to current dir
$oubuf =~ s|(href="[^ ]+path=)\.\/([^ ]+)|$1$pname$2|g;
    # expand img src="./ to current dir
    $oubuf =~ s|(img src=")\.\/([^ ]+)|$1$pname$2|g;


    $oubuf;
}

1;
