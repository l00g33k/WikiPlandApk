while [ 1 ]; do
busybox clear
echo shorthand: = is l00http_ , _ is l00_
echo m=periodic.pl.......2=perioifconfig.pl..3=periolog.pl.......
echo n=perionetstat.pl...2=play.pl...........3=playcopy.pl.......
echo o=readme.pl.........2=recedit.pl........3=reminder.pl.......
echo p=scratch.pl........2=screen.pl.........3=search.pl.........
echo q=shell.pl..........2=sleep.pl..........3=solver.pl.........
echo r=speech.pl.........2=table.pl..........3=tableedit.pl.....
echo s=timelog.pl........2=timestamp.pl......3=toast.pl..........
echo t=tr.pl.............2=twitter.pl........3=txtdopl.pl........
echo u=view.pl...........2=wget.pl...........3l00httpd.pl........
echo vl00httpd.pm........2l00mktime.pm.......3l00wget.pm.........
echo wl00wikihtml.pm.....2=filemgt.pl
echo xz exit
read sel
echo $sel

if [ $sel = "a" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00Blowfish_PP.pm; fi
if [ $sel = "aa" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00_ascii.pl; fi
if [ $sel = "aaa" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00_chart.pl; fi
if [ $sel = "b" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00_crypt_ex_1.pl; fi
if [ $sel = "bb" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00_crypt_ex_2.pl; fi
if [ $sel = "bbb" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00_do.pl; fi
if [ $sel = "c" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00_pwget.pl; fi
if [ $sel = "cc" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00_vil00httpd_.pl; fi
if [ $sel = "ccc" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00_wavgen.pl; fi
if [ $sel = "d" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00backup.pm; fi
if [ $sel = "dd" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00base64.pm; fi
if [ $sel = "ddd" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00crypt.pm; fi
if [ $sel = "e" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00host_filetools.pl; fi
if [ $sel = "ee" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_adb.pl; fi
if [ $sel = "eee" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_blog.pl; fi
if [ $sel = "f" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_cal.pl; fi
if [ $sel = "ff" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_clip.pl; fi
if [ $sel = "fff" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_coorcalc.pl; fi
if [ $sel = "g" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_crypt.pl; fi
if [ $sel = "gg" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_dirnotes.pl; fi
if [ $sel = "ggg" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_do.pl; fi
if [ $sel = "h" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_edit.pl; fi
if [ $sel = "hh" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_eval.pl; fi
if [ $sel = "hhh" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_filecrypt.pl; fi
if [ $sel = "i" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_find.pl; fi
if [ $sel = "ii" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_gps.pl; fi
if [ $sel = "iii" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_gpsmap.pl; fi
if [ $sel = "j" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_hello.pl; fi
if [ $sel = "jj" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_hexview.pl; fi
if [ $sel = "jjj" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_jetlag.pl; fi
if [ $sel = "k" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_kml.pl; fi
if [ $sel = "kk" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_launcher.pl; fi
if [ $sel = "kkk" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_ls.pl; fi
if [ $sel = "l" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_myfriends.pl; fi
if [ $sel = "ll" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_notify.pl; fi
if [ $sel = "lll" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_periocam.pl; fi
if [ $sel = "m" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_periodic.pl; fi
if [ $sel = "mm" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_perioifconfig.pl; fi
if [ $sel = "mmm" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_periolog.pl; fi
if [ $sel = "n" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_perionetstat.pl; fi
if [ $sel = "nn" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_play.pl; fi
if [ $sel = "nnn" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_playcopy.pl; fi
if [ $sel = "o" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_readme.pl; fi
if [ $sel = "oo" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_recedit.pl; fi
if [ $sel = "ooo" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_reminder.pl; fi
if [ $sel = "p" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_scratch.pl; fi
if [ $sel = "pp" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_screen.pl; fi
if [ $sel = "ppp" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_search.pl; fi
if [ $sel = "q" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_shell.pl; fi
if [ $sel = "qq" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_sleep.pl; fi
if [ $sel = "qqq" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_solver.pl; fi
if [ $sel = "r" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_speech.pl; fi
if [ $sel = "rr" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_table.pl; fi
if [ $sel = "rrr" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_tableedit.pl; fi
if [ $sel = "s" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_timelog.pl; fi
if [ $sel = "ss" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_timestamp.pl; fi
if [ $sel = "sss" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_toast.pl; fi
if [ $sel = "t" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_tr.pl; fi
if [ $sel = "tt" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_twitter.pl; fi
if [ $sel = "ttt" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_txtdopl.pl; fi
if [ $sel = "u" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_view.pl; fi
if [ $sel = "uu" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_wget.pl; fi
if [ $sel = "uuu" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00httpd.pl; fi
if [ $sel = "v" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00httpd.pm; fi
if [ $sel = "vv" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00mktime.pm; fi
if [ $sel = "vvv" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00wget.pm; fi
if [ $sel = "w" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00wikihtml.pm; fi
if [ $sel = "ww" ]; then
vim /sdcard/sl4a/scripts/l00httpd/l00http_filemgt.pl; fi

if [ $sel = "xz" ]; then
break; fi

done
