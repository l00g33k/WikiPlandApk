This is the Perl source code for WikiPland

Introduction
============

WikiPland is a Perl based wiki engine and web server that is designed to run on an Andrid phones but will also works on any platform where Perl is available, such as on Windows and Linux computers.

Getting Started
===============

There are several ways to get started with WikiPland

    code

As an APK on an Android phone
-----------------------------


In source code form on an Android phone
---------------------------------------

In source code form on any Windows, Linux, or other computer
------------------------------------------------------------

As a Red Hat Openshift Application
----------------------------------




